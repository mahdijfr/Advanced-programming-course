public interface Player {

    int[][] nextMove(int[][] positions, boolean white);
}

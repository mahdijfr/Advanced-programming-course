package error;

public class RequestTimeOut extends Error {
    public RequestTimeOut(int priority) {
        super(408, "Request Time Out", priority);
    }
}

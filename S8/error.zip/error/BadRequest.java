package error;

public class BadRequest extends Error{
    public BadRequest(int priority) {
        super(400, "Request", priority);
    }

}

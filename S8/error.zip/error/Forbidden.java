package error;

public class Forbidden extends Error{
    public Forbidden(int priority) {
        super(403, "Forbidden", priority);
    }

}

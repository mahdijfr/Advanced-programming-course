package error;

public class InternalServerError extends Error{
    public InternalServerError(int priority) {
        super(500, "Internal Server Error", priority);
    }

}

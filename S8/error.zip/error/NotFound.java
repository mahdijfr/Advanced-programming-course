package error;

public class NotFound extends Error{
    public NotFound(int priority) {
        super(404, "Not Found", priority);
    }

}

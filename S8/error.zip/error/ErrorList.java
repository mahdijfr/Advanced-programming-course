package error;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class ErrorList {
    private List<Error> errors = new ArrayList<>();;

    public void sortErrors() {
        this.errors.sort(Comparator.comparing(Error::getPriority));
    }

    public List<Error> getErrors() {
        return errors;
    }

    public void addError(Error error) {
        this.errors.add(error);
    }
}

package error;

public class Error {
    protected int code;
    protected String message;
    protected int priority;

    public  Error(int code, String message, int priority) {
        this.code = code;
        this.message = message;
        this.priority = priority;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }
}
